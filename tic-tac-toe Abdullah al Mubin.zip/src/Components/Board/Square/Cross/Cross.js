import React from 'react'

function Cross(props) {

    return <div className="cross symbol text-center" style={{ color: 'green'}}>X</div>
}

export default Cross;