import React from 'react'

function Zero(props) {

    return <div className=" symbol text-center" style={{ color: '#0dcaf0'}}>O</div>
}

export default Zero;