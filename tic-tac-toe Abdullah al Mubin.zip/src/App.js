import logo from './logo.svg';
import './App.css';

import Board from './Components/Board/Borard';

function App() {
  return (
    <div className="container">
      <div className="row">
        
          <Board />
        
      </div>

    </div>
  );
}

export default App;
