export const DRAW_X = "DRAW_X";
export const DRAW_Y = "DRAW_Y";
export const RESET_BOARD = "RESET_BOARD";

export const PLAYER_X = "PLAYER_X";
export const PLAYER_O = "PLAYER_O"
export const TURN = "TURN"
export const RESET_PLAYER = 'RESET_PLAYER'

export const X_WINS = 'X_WINS';
export const O_WINS = 'O_WINS'
export const DRAW = 'DRAW';
export const RESET_RESULT = 'RESET_RESULT'